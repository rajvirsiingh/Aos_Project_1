package lifeGame;

public class BoardController {

	public void updated(BoardModel m);
	
}
